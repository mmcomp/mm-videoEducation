<?php
//var_dump($_REQUEST);
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : -1;
if($product_id==-1){
    echo "no input";
    exit();
}
$title = get_the_title($product_id);
$csv = isset($_GET['csv']) ? 1 : 0;
if($csv==1){
    $path = plugin_dir_path( __FILE__ ).'download';
    $file_name = 'videoreport-'.date("Y-m-d-H-i-s").'.csv';
    file_put_contents($path.'/'.$file_name,hamayesh_class::getVideoProductReport($product_id,1));
    $url= plugins_url().'/HShamayesh/admin/download/'.$file_name;
    wp_redirect($url);
}
?>
<div>
    <h2>
        فهرست خریداران جلسات مجازی: 
        <?php echo $title; ?>
    </h2>
    <a style="float:left" class="button button-primary button-large" target="_blank" href='admin.php?page=video-product-rp&product_id=<?php echo $product_id; ?>&csv=1' >csv</a>
</div>
<?php
echo hamayesh_class::getVideoProductReport($product_id);