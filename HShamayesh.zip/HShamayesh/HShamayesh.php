<?php
/*
  Plugin Name: افزونه همایش ووکامرس
  Description: پلاگین تبدیل یک کالا به همایش و تعریف صندلی ،برای عارف نوشته شده است
 */
/* Start Adding Functions Below this Line */

/* Stop Adding Functions Below this Line */
define('HSRESERVE_PATH', dirname(__FILE__) . '/');
define('HSRESERVE_PATH_SETTINGS_SET_ADMIN_CAP', 'manage_options');
define('HSRESERVE_PATH_SETTINGS_SET_USER_CAP', 'read');
define('HTTP_PATH', get_site_url(). '/wp-content/plugins/HShamayesh');

foreach (glob(HSRESERVE_PATH . "class/*.php") as $file) {
    include_once $file;
}
//hamayesh_class::getChairs(2088);
class HShamayesh{
    public function __construct() {
        //------backend
        add_filter('product_type_options', 'HShamayesh::add_hamaiesh_product_option');
        add_filter('woocommerce_product_data_tabs', 'HShamayesh::custom_product_tabs');
        add_filter('woocommerce_product_data_panels', 'HShamayesh::hamaiesh_options_product_tab_content');
        add_action( 'admin_enqueue_scripts', 'HShamayesh::adminInclude' );
        // - save custom feilds
        add_action('woocommerce_process_product_meta_simple', 'hamayesh_class::save_hamayesh_option_fields');
        add_action('woocommerce_process_product_meta_variable', 'hamayesh_class::save_hamayesh_option_fields');
        // adding custom menu
        add_action( 'admin_menu', 'HShamayesh::hamyesh_menu_report' );
        //admin pages
        add_filter( 'manage_edit-product_columns', 'hamayesh_class::hamayesh_report_column',11);
        add_action( 'manage_product_posts_custom_column', 'hamayesh_class::hamayesh_column_report_function', 10, 2 );

        //################# AJAX ###############################
        add_action("wp_ajax_hs_save_hamayesh", "hamayesh_class::hs_save_hamayesh");
        add_action("wp_ajax_hs_save_static_hamayesh", "hamayesh_class::hs_save_static_hamayesh");
        add_action("wp_ajax_hs_deletechair_hamayesh", "hamayesh_class::hs_deletechair_hamayesh");
        //############################## front end #####################################
        add_action("woocommerce_before_add_to_cart_button", "hamayesh_class::showReserveOptions");
        add_action('wp_enqueue_scripts','HShamayesh::jsInclude');
        add_filter( 'woocommerce_add_cart_item_data', 'hamayesh_class::add_cart_item_data', 10, 3 );//upadte price when click on add to cart
        add_filter( 'woocommerce_get_item_data', 'hamayesh_class::show_chairs_oncart', 10, 2 );
        add_action( 'woocommerce_before_calculate_totals', 'hamayesh_class::add_custom_price' );
        add_action( 'woocommerce_checkout_create_order_line_item', 'hamayesh_class::reserve_chairs',20,4);
        add_action('woocommerce_thankyou', 'hamayesh_class::send_sms', 10, 1);
        add_action('woocommerce_after_add_to_cart_button','hamayesh_class::get_reserved_chairs');
        add_action( 'woocommerce_single_product_summary', 'hamayesh_class::remove_add_to_cart_buttons', 1 );
        add_action( 'woocommerce_checkout_process', 'hamayesh_class::checkout_validation');

        //---------------- WooCommerce Archive Page -------------
        add_action('init', function(){
            remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
            add_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 7);
         });
        add_action( 'woocommerce_after_shop_loop_item_title', 'hamayesh_class::hs_add_custom_title', 10 );
    }
    public static function hamyesh_menu_report(){
        add_submenu_page(
            'woocommerce',
            'گزارش همایشها',     // page title
            'گزارش همایشها',     // menu title
            'manage_options',   // capability
            'hamayesh-product-rp',     // menu slug
            'HShamayesh::hamayesh_report_render' // callback function
        ); 
        // add video report page
        add_submenu_page(
            'woocommerce',
            'گزارش جلسات مجازی',     // page title
            'گزارش جلسات مجازی',     // menu title
            'manage_options',   // capability
            'video-product-rp',     // menu slug
            'HShamayesh::video_report_render' // callback function
        ); 

    }
    // mange video report page
    public static function video_report_render(){
        global $title;

        print '<div class="wrap">';
        print "<h1>$title</h1>";

        $file = plugin_dir_path( __FILE__ ) . "admin/video-rp.php";

        if ( file_exists( $file ) )
            require $file;
    }
    public static function hamayesh_report_render(){
        global $title;

        print '<div class="wrap">';
        print "<h1>$title</h1>";

        $file = plugin_dir_path( __FILE__ ) . "admin/product-rp.php";

        if ( file_exists( $file ) )
            require $file;
    }
    public function add_hamaiesh_product_option($product_type_options) {
        $id = get_the_ID();
        $product_type_options['hamayesh'] = array(
            'id' => '_is_hamayesh',
            'wrapper_class' => 'show_if_simple show_if_variable',
            'label' => __('همایش', 'woocommerce'),
            'description' => __('این آیتم در قالب همایش و به صورت صندلی قابل فروش خواهد بود.', 'woocommerce'),
            'default' => get_post_meta($id, '_is_hamayesh', true)
        );
        ?>
        <script>
            jQuery(document).ready(function ($) {
                $('input#_is_hamayesh').change(function () {
                    var is_gift_card = $('input#_is_hamayesh:checked').size();
                    $('.show_if_hamayesh').hide();                  
                    if (is_gift_card) {
                        $('.show_if_hamayesh').show();
                        $('#_virtual').prop("checked",true);
                        $('#_sold_individually').prop("checked",true);
                    }
                });
                $('input#_is_hamayesh').trigger('change');
            });
            function hs_hamayesh_save_data(obj) {
                var data = {
                    "_hamayesh_start": jQuery("#_hamayesh_start").val(),
                    "_hamayesh_end": jQuery("#_hamayesh_end").val(),
                    "_hamayesh_ghimat": jQuery("#_hamayesh_ghimat").val(),
                    "_hamayesh_toz": jQuery("#_hamayesh_toz").val(),
                    "_hamayesh_woo_post_id": <?php echo $id; ?>,
                    "action": "hs_save_hamayesh"
                };
                jQuery("#hs_hamayesh_tb").append('<img class="khoon" src="images/loading.gif" >');
                jQuery(obj).hide();
                jQuery.post(ajaxurl, data, function (response) {
                    res = JSON.parse(response);
                    if(res.err=='1'){
                        alert(res.msg);
                        jQuery(".khoon").remove();
                        jQuery("#hs_hamayesh_tb").append('<span class="khoon">'+res.msg+'</span>');
                        return false;
                    }
                    else{
                        alert(res.msg);
                        jQuery("#hs_hamayesh_tb").html(res.data.det);
                        $("#_hamayesh_ghimat").val('');
                        $("#_hamayesh_start").val(parseInt($("#_hamayesh_end").val())+1);
                        $("#_hamayesh_end").val('');
                        $("#_hamayesh_toz").val('');
                    }
                    
                }).fail(function () {
                    alert('خطا در ارتباط با سرور');
                }).always(function () {
                    jQuery(obj).show();
                });
                return false;
            }
        </script>
        <?php
        return $product_type_options;
    }
    public static function custom_product_tabs($tabs) {
        $tabs['hamayesh'] = array(
            'label' => __('امکانات همایش', 'woocommerce'),
            'target' => 'hamayesh_options',
            'class' => array('show_if_hamayesh'),
        );
        return $tabs;
    }
    public static function hamaiesh_options_product_tab_content() {
        $id = get_the_ID();
        //$reserver = new reserve_class;
        //$out = $reserver->getReserve(get_the_ID());
        // Note the 'id' attribute needs to match the 'target' parameter set above
        ?>
        <form id="hamayesh_form" name="hamayesh_form" >
            <div id='hamayesh_options' class='panel woocommerce_options_panel'><?php ?><div class='options_group'>
                <div id="hs_hamayesh_tb" >
                <?php
                    $ha = new hamayesh_class;
                    $q = $ha->getHamayeshDetails($id);
                    echo $ha->showHamayesh($q);
                ?>
                </div>
                <?php
                    
                    echo '<div id="hs-reserve-div" >' . $out . '</div><div style="display:none;text-align:center" id="khoon" >درحال بارگذاری ...</div>';
                    $no_tarikh = (int)get_post_meta($id, '_no_tarikh', true);
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_tarikh',
                        'label' => __('تاریخ', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => $no_tarikh==1? '':audit_class::hamed_pdate(get_post_meta($id, '_tarikh', true)),
                        'name' => '_hamayesh_tarikh',
                        'description' => __('تاریخ روز مورد نظر را وارد نمایید.', 'woocommerce'),
                        'type' => 'text'
                    ));
                    woocommerce_wp_select( [
                        'id' => '_hamayesh_no_tarikh',
                        'label' => __('بدون تاریخ', 'woocommerce'),
                        'desc_tip' => 'true',
                        //'checked' =>get_post_meta($id, '_no_tarikh', true)==1 ? 'checked': '' ,
                        'options'=>[
                            '1'=>'بله',
                            '0'=>'خیر'
                        ],
                        'value'=>$no_tarikh,
                        'name' => '_hamayesh_no_tarikh',
                        'description' => __('در صورت فعال سازی این گزینه تاریخ بی معنی خواهد شد', 'woocommerce'),
                    ] );
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_time',
                        'label' => __('ساعت', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => get_post_meta($id, '_time', true),
                        'name' => '_hamayesh_time',
                        'description' => __(' ساعت مورد نظر را وارد نمایید.', 'woocommerce'),
                        'type' => 'time',
                        'style'=>'float:right'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_address',
                        'label' => __('نشانی', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => get_post_meta($id, '_address', true),
                        'name' => '_hamayesh_address',
                        'description' => __('نشانی محل برگزاری همایش را وارد کنید', 'woocommerce'),
                        'type' => 'text'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_teacher',
                        'label' => __('استاد', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => get_post_meta($id, '_teacher', true),
                        'name' => '_hamayesh_teacher',
                        'description' => __('نام استاد همایش را ذکر کنید', 'woocommerce'),
                        'type' => 'text'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_city',
                        'label' => __('شهر', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => get_post_meta($id, '_city', true),
                        'name' => '_hamayesh_city',
                        'description' => __('شهر محل برگزاری همایش را وارد کنید', 'woocommerce'),
                        'type' => 'text'
                    ));
                    ?>
                    <button id="hamayesh_static" type="button" class="button button-primary" onclick="hs_hamayesh_save_static_data(<?php echo $id ?>,this)"> ذخیره </button>
                    <span id="hamayesh_static_span" ></span>
                    <?php
                    $MinMaz = hamayesh_class::getHamayeshMinMax($id);
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_start',
                        'label' => __('از شماره', 'woocommerce'),
                        'desc_tip' => 'true',
                        'value' => $MinMaz['max']+1 ,
                        'description' => __('  نخستین شماره صندلی را وارد نمایید.', 'woocommerce'),
                        'type' => 'number'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_end',
                        'label' => __('تا شماره', 'woocommerce'),
                        'desc_tip' => 'true',
                        'description' => __('آخرین شماره صندلی را وارد نمایید.', 'woocommerce'),
                        'type' => 'number'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_ghimat',
                        'label' => __('قیمت', 'woocommerce'),
                        'desc_tip' => 'true',
                        'description' => __('قیمت شماره صندلی های معین شده را مشخص کنید.', 'woocommerce'),
                        'type' => 'number'
                    ));
                    woocommerce_wp_text_input(array(
                        'id' => '_hamayesh_toz',
                        'label' => __('توضیحات کوتاه', 'woocommerce'),
                        'desc_tip' => 'true',
                        'description' => __('توضیحاتی کوتاه کاربردی هنگام خرید برای خریدار.', 'woocommerce'),
                        'type' => 'text'
                    ));
                    ?></div>

                <button type="button" class="button button-primary" onclick="hs_hamayesh_save_data(this)"> افزودن </button>
            </div>
        </form>
        <style>
            .hs-table{
                width: 100%
            }

            .hs-table td{
                border: solid 1px #999999;
                padding: 4px;
            }
            .hs-table tr:nth-child(even) {background: #CCC}
        </style>
        <?php
    }
    public function jsInclude() {
        //wp_enqueue_script( 'jquery2', plugins_url( '/js/jquery-1.12.4.min.js', __FILE__ ));
        wp_enqueue_script( 'multiselectjs', plugins_url( '/js/jquery.multiselect.js', __FILE__ ));
        wp_enqueue_style( 'multiselect', plugins_url( '/css/jquery.multiselect.css' , __FILE__ ) );
        wp_enqueue_style( 'hamayesh', plugins_url( '/css/hamayesh.css' , __FILE__ ) );
        //wp_enqueue_style( 'multiselect' );
    }
    public static function adminInclude(){
        wp_enqueue_script( 'hamayeshjs', plugins_url( '/js/hamayesh.js', __FILE__ ));
    }
    
}

$hamaiesh = new HShamayesh();
