<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of reserve_class
 *
 * @author hscomp
 */
class hamayesh_class {

    //put your code here
    public $prefix;
    public function __construct($id = -1) {
        global $wpdb;
        $table_prefix = $wpdb->prefix;
        $this->prefix = $table_prefix;
        /*
        if ((int) $id > 0) {
            $pre = $this->prefix;
            $mysql = new mysql_class;
            $mysql->ex_sql("select * from ".$pre."hamayesh_data where `id` = $id", $q);
            foreach ($q[0] as $fi => $val) {
                $this->$fi = $val;
            }
            
        }
        */
    }
    public static function hs_save_hamayesh() {
        $tmp1 = '';
        $tmp2 = '';
        global $wpdb;
        $pre = $wpdb->prefix;
        foreach ($_POST as $key => $val) {
            $tmp = explode("_",$key);
            if ($key != 'action') {
                if(isset($tmp[1]) && $tmp[1]=='hamayesh'){
                    $key = str_replace("_hamayesh_", '', $key);
                    $tmp1 .= ($tmp1 == '' ? '(' : ',' ) . $key;
                    $tmp2 .= ($tmp2 == '' ? '(' : ',' ) . "'$val'";
                }
            }
        }
        
        $start = (int)$_POST['_hamayesh_start'];
        $end = (int)$_POST['_hamayesh_end'];
        $p_id = (int)$_POST['_hamayesh_woo_post_id'];
        $ghimat = (int)$_POST['_hamayesh_ghimat'];
        if($start<=0){
            $out = ['err'=>'1','msg'=>'شماره شروع را صحیح وارد کنید','data'=>[]];
            die(json_encode($out));
        }
        if($end<=0){
            $out = ['err'=>'1','msg'=>'شماره خاتمه را صحیح وارد کنید','data'=>[]];
            die(json_encode($out));
        }
        if($end<$start){
            $out = ['err'=>'1','msg'=>'شماره صندلی شروع از پایان بیشتر واردشده است','data'=>[]];
            die(json_encode($out));
        }
        if($ghimat<=0){
            $out = ['err'=>'1','msg'=>'قیمت را صحیح وارد کنید','data'=>[]];
            die(json_encode($out));
        }
        $range = hamayesh_class::getHamayeshMinMax($p_id);
        if(   ($range['min']<=$start  && $range['max']>=$start) || ($range['min']<=$end  && $range['max']>=$end) ){
            $out = ['err'=>'1','msg'=>'خطا در ثبت لطفا شماره صندلی های وارد شده را چک نمایید تکراری نباشد','data'=>[($range['min']<=$end  && $range['max']>=$end),($range['min']<=$start  && $range['max']>=$start),$range]];
            die(json_encode($out));
        }
        $tmp1 .= ')';
        $tmp2 .= ')';
        
        $qu = "insert into ".$pre."hamayesh_data $tmp1 values $tmp2";
        $my = new mysql_class;
        $my->ex_sqlx($qu);
        $rr = new hamayesh_class;
        $out = ['err'=>'0','msg'=>'ثبت با موفقیت انجام شد','data'=>['det'=>$rr->showHamayesh($rr->getHamayeshDetails($p_id))],'tarikh'=>$tarikh];
        die(json_encode($out));
    }
    public static function hs_save_static_hamayesh() {
        $p_id = (int)$_POST['_hamayesh_woo_post_id'];
        $no_tarikh = $_POST['_no_tarikh'];
        if($no_tarikh==0){
            $tarikh = audit_class::hamed_pdateBack($_POST['_tarikh'],FALSE);
        }
        else{
            $tarikh = '2040-12-12';
        }
        $time = $_POST['_time'];
        $address = $_POST['_address'];
        $teacher = $_POST['_teacher'];
        $city = $_POST['_city'];
        update_post_meta($p_id, '_tarikh', $tarikh);
        update_post_meta($p_id, '_no_tarikh', $no_tarikh);        
        update_post_meta($p_id, '_time', $time);
        update_post_meta($p_id, '_address', $address);
        update_post_meta($p_id, '_teacher', $teacher);
        update_post_meta($p_id, '_city', $city);
        $out = ['err'=>'0','msg'=>'ثبت با موفقیت انجام شد','data'=>[]];
        die(json_encode($out));
    }
    public static function showReserveOptions() {
        $out = '';
        $id = get_the_ID();
        $ham = new hamayesh_class();
        $q = $ham->getHamayeshDetails($id);
        if (get_post_meta($id, '_is_hamayesh', true) == 'yes'  && count($q)>0) {
               $saled_chairs = hamayesh_class::getChairs($id);
                $out = '<div class="hs-hamayesh-div"><label for="reserve_time"> انتخاب شماره صندلی</label>
                <select id="hamayesh_chairs" name="chairs[]" multiple="multiple" class="3col active" >';

                foreach ($q as $r) {
                    $out .='<optgroup label="'.($r['toz']!='' ? $r['toz']: 'قیمت').' - '.$r['ghimat'].' -تومان ">';
                    for($i=$r['start'];$i<=$r['end'];$i++){
                        if(!in_array($i,$saled_chairs)){
                            $out .='<option value="'.$i.'">شماره '.$i.'</option>';        
                        }
                    }
                    $out .='</optgroup>';
                }
                $out .= '</select></div> <div class="hs-hamayesh-div-msg" ></div>
                ';
        
        //echo coupon_class::getCouponCode(1200);
            echo "<script>jQuery(document).ready(function(){
                    jQuery(function () {
                        jQuery('select[multiple].active.3col').multiselect({
                            columns: 3,
                            placeholder: 'انتخاب صندلی',
                            search: false,
                            searchOptions: {
                                'default': '1'
                            },
                            selectAll: false,
                            maxWidth: '100%'
                        });
                
                    });
                    jQuery('.quantity').hide();
                    jQuery('button[name*=add-to-cart]').on('click',function(event){
                        if(!jQuery('#hamayesh_chairs').val()){
                            event.preventDefault();
                        jQuery('.hs-hamayesh-div-msg').html('لطفا حداقل یک صندلی انتخاب نمایید');
                        }
                        else{
                            jQuery(this).trigger('click');
                        }
                    });
                });
            </script>
            <style>
                .hs-hamayesh-div-msg{
                    margin: 10px 0 10px 0 ;
                    color: red;
                    font-weight:bold;
                }
            </style>
            ";
        }
        //echo (count($q) > 0 ? $out : '');
        echo  $out;
    }
    public static function save_hamayesh_option_fields($post_id) {
        /*
          $allow_personal_message = isset($_POST['_allow_personal_message']) ? 'yes' : 'no';
          update_post_meta($post_id, '_allow_personal_message', $allow_personal_message);

          if (isset($_POST['_valid_for_days'])) :
          update_post_meta($post_id, '_valid_for_days', absint($_POST['_valid_for_days']));
          endif;
         * 
         */
        $is_reserve = isset($_POST['_is_hamayesh']) ? 'yes' : 'no';
        update_post_meta($post_id, '_is_hamayesh', $is_reserve);
    }
    public function getHamayeshDetails($post_id){
        $pre = $this->prefix;
        $mysql = new mysql_class;
        $mysql->ex_sql("select * from ".$pre."hamayesh_data where `woo_post_id` = $post_id order by start", $q);
        return $q;
    }
    public function showHamayesh($q){
        $out = '';
        if(count($q)>0){
            $out = '
            <table class="hs-table">
                <tr>
                    <td>
                    
                    </td>
                    <td>
                    ردیف
                    </td>
                    <td>
                    از شماره
                    </td>
                    <td>
                        تا شماره
                    </td>
                    <td>
                        قیمت
                    </td>
                    <td>
                        توضیحات
                    </td>
                </tr>
            ';
            $i=1;
            foreach($q as $r){
                $out.='
                <tr>
                    <td>
                        <span> <a style="cursor: pointer" onclick="deletechair('.$r['id'].','.$r['woo_post_id'].')" ><img style="width:16px" src="'.HTTP_PATH.'/img/hs-bin.png" alt="delete" ></a></span>
                    </td>
                    <td>
                    '.$i.'
                    </td>
                    <td>
                    '.$r['start'].'
                    </td>
                    <td>
                    '.$r['end'].'
                    </td>
                    <td>
                    '.$r['ghimat'].'
                    </td>
                    <td>
                    '.$r['toz'].'
                    </td>
                </tr>
                ';
                $i++;
            }
            $out.='</table>';
        }
        return $out;
    }
    public function hs_deletechair_hamayesh() {
        global $wpdb;
        $hamayesh_data_id = (isset($_POST['hamayesh_data_id']) ? ($_POST['hamayesh_data_id']) : -1);
        $post_id = (isset($_POST['hs_post_id']) ? ($_POST['hs_post_id']) : -1);
        $my = new mysql_class;
        $my->ex_sqlx("delete from ".$wpdb->prefix."hamayesh_data where id=$hamayesh_data_id");
        $rr = new hamayesh_class;
        $out = $rr->showHamayesh($rr->getHamayeshDetails($post_id));
        die($out);
    }
    public function getHamayeshMinMax($post_id){
        global $wpdb;
        $pre = $wpdb->prefix;
        $my = new mysql_class;
        $my->ex_sql("select MIN(start) as kam,MAX(end) as bish from ".$pre."hamayesh_data where woo_post_id=$post_id",$p);
        $out = ['min'=>0,'max'=>0];
        if(count($p)>0){
            $out = ['min'=>$p[0]['kam'],'max'=>$p[0]['bish']];
        }
        return $out;
    }
    public static function add_cart_item_data($cart_item_data, $product_id, $variation_id){
        if(get_post_meta($product_id, '_is_hamayesh', true) == 'yes'){
            $cart_item_data['warranty_price'] = hamayesh_class::getGhimat($_POST['chairs'],$product_id);
            $cart_item_data['chairs'] = $_POST['chairs'];
        }
        return $cart_item_data;
    }
    public static function show_chairs_oncart( $cart_data, $cart_item ){
        $custom_items = array();
        if( !empty( $cart_data ) )
            $custom_items = $cart_data;
        $product_id = $cart_item['product_id'];
        if(get_post_meta($product_id, '_is_hamayesh', true) == 'yes'){
            $custom_items[] = array(
                'name'      => __( 'شماره صندلی/ها', 'woocommerce' ),
                'value'     => $cart_item['chairs'],
                'display'   => implode(' , ',$cart_item['chairs'])
            );
        }
        return $custom_items;
    }
    public static function getGhimat($chairs,$product_id){
        $my = new mysql_class;
        global $wpdb;
        $ghimat = 0;
        foreach($chairs as $number){
            $q = null;
            $my->ex_sql("select ghimat from ".$wpdb->prefix."hamayesh_data where woo_post_id=$product_id and start<=$number and end>=$number limit 1",$q);
            if(count($q)>0){
                $ghimat+=$q[0]['ghimat'];
            }
        }
        return $ghimat;
    }
    public static function add_custom_price($cart_object){
        foreach ( $cart_object->get_cart() as $key => $value ) {
            if( isset( $value['warranty_price'] ) ) {
                $price = $value['warranty_price'];
                $value['data']->set_price($price);
                /*
                $name='';
                foreach($value['chairs'] as $number){
                    $name .= ( $name=='' ? '':',').'صندلی '.$number;
                }
                $value['data']->set_name($value['data']->name.'<br/>'.$name);
                */
                //$value['data']->set_quantity(3);
            }
        }
    }
    public static function reserve_chairs($item, $cart_item_key, $values, $order ) {
        if(isset($values['chairs'])){
            $item->update_meta_data('chairs', implode(',',$values['chairs']));
        }
    }
    public static function getChairs( $product_id, $order_status = ['wc-completed','wc-processing','wc-pending']  ){
        global $wpdb;
        $my = new mysql_class;
        $out=[];
        $results = $my->ex_sql("
            SELECT order_items.order_item_id 
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
            group by order_items.order_item_id
        ",$q);
        
        $tmp = '';
        foreach($q as $r){
            $my->ex_sql("
            select meta_value 
            FROM {$wpdb->prefix}woocommerce_order_itemmeta as order_items
            where meta_key = 'chairs' 
            AND order_item_id=".$r['order_item_id'],$p);
            $tmp .= ($tmp==''?'':',').$p[0]['meta_value'];
            $p=null;
        }
        $out = explode(',',$tmp);
        sort($out);
        return $out;
    }
    public static function send_sms( $order_id ) {
        if ( ! $order_id )
            return;

        // Getting an instance of the order object
        $order = wc_get_order( $order_id );
        // iterating through each order items (getting product ID and the product object) 
        // (work for simple and variable products)
        foreach ( $order->get_items() as $item_id => $item ) {
            if( $item['variation_id'] > 0 ){
                $product_id = $item['variation_id']; // variable product
            } else {
                $product_id = $item['product_id']; // simple product
            }
            $sms_sent = (int)get_post_meta($order_id, '_smsSent', true)==1;
            if(!$sms_sent){
                $is_hamayesh = get_post_meta($product_id, '_is_hamayesh', true);
                $tarikh = jdate("Y/m/d",strtotime(get_post_meta($product_id, '_tarikh')[0]));
                $addr = get_post_meta($product_id, '_address', true);
                $time = get_post_meta($product_id, '_time', true);
                //$current_user = wp_get_current_user();
                if($is_hamayesh=='yes'){
                    $hamayesh_name = get_the_title($product_id);
                    $item_meta= wc_get_order_item_meta($item_id,'chairs');
                    $sms_text = '
                    سلام،
                    کاربر عزیز 
                    '.get_post_meta($order_id, '_billing_first_name', true). ' '.get_post_meta($order_id, '_billing_last_name', true).'
                    ثبت نام شما در 
                    '.$hamayesh_name .'
                    در تاریخ: 
                    '.$tarikh.'
                    ساعت:
                    '.$time.'
                    با موفقیت انجام شد. در ضمن شماره/های صندلی شما
                    '.$item_meta.' 
                    می باشد
                    لطفا قبل از شروع همایش در محل سالن همایش:
                    '.$addr.'
                    حضور داشته باشید
                    با احترام خانه کنکور عارف
                            ';
                }
                $mobile = get_post_meta($order_id, '_billing_phone', true);
                //echo $mobile;
                $sent =SmsHelper::send($mobile, trim(preg_replace('/\s+/', ' ', $sms_text)));
                if($sent){
                    
                    update_post_meta($order_id, '_smsSent',1);
                }
            }
        }
        
    }
    public static function get_reserved_chairs(){
        $product_id = get_the_ID();
        $chairs= hamayesh_class::getChairs($product_id);
        //$chairs=array_unique($chairs);
        if(get_post_meta($product_id, '_is_hamayesh', true) == 'yes'){
            echo 
            "<div class='hamayesh_reserved_chair' >
                <span>
                    صندلی های خریداری شده تا کنون:
                </span>
                <div>
                ".implode( ' , ', $chairs )."
                </div>
            </div>
            <style>
            .hamayesh_reserved_chair{
                clear:both;
                padding-top:10px;
            }
            </style>
            ";
        }
    }
    public static function remove_add_to_cart_buttons() {
        global $product;
        global $woocommerce;
        $items = $woocommerce->cart->get_cart();
        $product_id = get_the_ID();
        $tarikh = get_post_meta($product_id,'_tarikh',true);
        $time = get_post_meta($product_id,'_time',true);
        $date_tmp = strtotime($tarikh.' '.$time);
        $now = strtotime(date("Y-m-d H:i:s"));
        if( $date_tmp < $now){
            $notice ='به علت پایان مهلت ثبت نام امکان ثبت نام وجود ندارد';
            wc_print_notice( $notice, 'notice' );
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
            return;
        }
        $in_cart = false;
        foreach( $items as $cart_item ) {
            $product_in_cart = $cart_item['product_id'];
            if ( $product_in_cart === $product_id ) $in_cart = true;
         }
          
             if ( $in_cart ) {
          
                 $notice ='این همایش به سبد خرید افزوده شده است امکان سفارش مجدد وجود ندارد';
                 wc_print_notice( $notice, 'notice' );
          
             }
          
        
        //var_dump($items);
        // For simple product types
        if( $product->is_type( 'simple' ) && get_post_meta($product_id, '_is_hamayesh', true)=='yes' && $in_cart ) {
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
        }

    }
    public static function checkout_validation(){
        $items = WC()->cart->get_cart();
        $notAlow=[];
        $msg = '';
        foreach ($items as $item => $values)
        {
            $product_id = $values['product_id'];
            $name = $values['data']->post->post_title;
            $avail = hamayesh_class::getChairs($product_id);
            foreach($values['chairs'] as $number){
                if(in_array($number,$avail)){
                    $notAlow[] = $number;
                }
            }
            if(count($notAlow)>0){
                $msg .='متاسفانه شماره صندلی/های  '.implode(',',$notAlow).' از '.$name.' در همین لحظه توسط شخص دیگری رزرو شد لطفا به 
                <a style="color:yellow" href="'.get_site_url().'/cart" >
                سبد خرید
                </a>
                 خود بازگردید و این آیتم را حذف کنیدو مجدد صندلی دیگری انتخاب کنید.'.'<br/>';
            }
        }
        if($msg!=''){
            wc_add_notice($msg, 'error' );
        }
    }
    // load video session name
    public static function getVideoSession($video_sessions) {
        $video_sessions = trim($video_sessions);
        if($video_sessions=='') {
            return 'همه';
        }
        global $wpdb;
        $my = new mysql_class;
        $out=[];
        $results = $my->ex_sql("
            SELECT name
            FROM {$wpdb->prefix}video_session 
            WHERE id in ($video_sessions)
        ",$q);
        foreach($q as $r){
            $out[] = $r['name'];
        }
        if(count($out)>0) {
            return implode(',', $out);
        }
        return '-';
    }
    // main video report content
    public static function getVideoProductReport($product_id,$csv=0,$order_status = ['wc-completed','wc-processing']){
        global $wpdb;
        $my = new mysql_class;
        $out=[];
        $results = $my->ex_sql("
            SELECT order_items.order_item_id,order_items.order_id
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
            group by order_items.order_item_id
        ",$q);
        $out= '';
        if($csv==0){
            $out = '<table class="wp-list-table widefat fixed striped posts">';
            $out .= '<tr>
                <th>
                نام و نام خانوادگی
                </th>
                <th>
                تلفن
                </th>
                <th>
                    جلسه
                </th>
                <th>
                    قیمت
                </th>
                <th>
                    تخفیف
                </th>
                <th>
                    پرداختی
                </th>
            </tr>';
        }
        else{
            $out .=trim(preg_replace('/\s\s+/', ' ', '
                نام و نام خانوادگی
                ,
                تلفن
                ,
                    جلسه
                ,
                    قیمت
                ,
                    تخفیف
                ,
                    پرداختی
                '))."\n";
        }
        $jam_ghimat = 0;
        $jam_ghimat_origin = 0;
        $jam_takhfif = 0;
        foreach($q as $r){
            $chairs = wc_get_order_item_meta($r['order_item_id'],'video_sessions',true);
            $ghimat = wc_get_order_item_meta($r['order_item_id'],'_line_total',true);
            $ghimat_origin = wc_get_order_item_meta($r['order_item_id'],'_line_subtotal',true);
            $takhfif = $ghimat_origin - $ghimat;
            $order = wc_get_order( $r['order_id']);
            $coupons = '';
            if( $order->get_used_coupons() ){
                foreach( $order->get_used_coupons() as $coupon) {
                    $coupons .= ($coupons==''? '':'/' ). $coupon;
                }
            }
            $jam_ghimat+= $ghimat;
            $jam_ghimat_origin += $ghimat_origin;
            $jam_takhfif += $takhfif;
            $fname = get_post_meta($r['order_id'],'_billing_first_name',true);
            $lname = get_post_meta($r['order_id'],'_billing_last_name',true);
            $name = $fname.' '.$lname;
            $phone = get_post_meta($r['order_id'],'_billing_phone',true);
            if($phone==''){
                $user_id = get_post_meta($r['order_id'],'_customer_user',true);
                $us = get_user_by( 'id', $user_id );
                $phone = $us->user_login;
            }
            if($fname=='' && $lname==''){
                $user_id = get_post_meta($r['order_id'],'_customer_user',true);
                $name = get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
            }
            if($csv==0){
                $out .= 
                '<tr>
                    <td>
                    '.$name.'
                    </td>
                    <td>
                    '.$phone.'
                    </td>
                    <td>
                    '.hamayesh_class::getVideoSession($chairs).'
                    </td>
                    <td>
                        '.hamayesh_class::monize($ghimat_origin).'
                    </td>
                    <td>
                        '.hamayesh_class::monize($takhfif).' <br/> '.$coupons.'
                    </td>
                    <td>
                        '.hamayesh_class::monize($ghimat).'
                    </td>
                </tr>';
            }
            else{
                 
                $out.=trim(preg_replace('/\s\s+/', ' ', $name.',
                '.$phone.',
                '.hamayesh_class::getVideoSession($chairs).',
                '.$ghimat_origin.',
                '.$takhfif.',
                '.$ghimat.'
                '))."\n";
            }
            $p=null;
        }
        if($csv==0){
            $out.="<tr><td colspan='3' style='text-align:left' >جمع کل</td>
        <td>".hamayesh_class::monize($jam_ghimat_origin)."</td>
        <td>".hamayesh_class::monize($jam_takhfif)."</td>
        <td>".hamayesh_class::monize($jam_ghimat)."</td>
        </tr>";
        $out.='</table>';
        }
        else{
            $out.= trim(preg_replace('/\s\s+/', ' ', ",,,
            جمع کل
            ,
            ".$jam_ghimat_origin.",
            ".$jam_takhfif.",
            ".$jam_ghimat));
        }
        return $out;
    }
    public static function getProductReport($product_id,$csv=0,$order_status = ['wc-completed','wc-processing']){
        global $wpdb;
        $my = new mysql_class;
        $out=[];
        $results = $my->ex_sql("
            SELECT order_items.order_item_id,order_items.order_id
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
            group by order_items.order_item_id
        ",$q);
        $out= '';
        if($csv==0){
            $out = '<table class="wp-list-table widefat fixed striped posts">';
            $out .= '<tr>
                <th>
                نام و نام خانوادگی
                </th>
                <th>
                تلفن
                </th>
                <th>
                    معرف
                </th>
                <th>
                    شماره صندلی
                </th>
                <th>
                    قیمت
                </th>
                <th>
                    تخفیف
                </th>
                <th>
                    پرداختی
                </th>
            </tr>';
        }
        else{
            $out .=trim(preg_replace('/\s\s+/', ' ', '
                نام و نام خانوادگی
                ,
                تلفن
                ,
                    معرف
                ,
                    شماره صندلی
                ,
                    قیمت
                ,
                    تخفیف
                ,
                    پرداختی
                '))."\n";
        }
        $jam_ghimat = 0;
        $jam_ghimat_origin = 0;
        $jam_takhfif = 0;
        foreach($q as $r){
            $chairs = wc_get_order_item_meta($r['order_item_id'],'chairs',true);
            $ghimat = wc_get_order_item_meta($r['order_item_id'],'_line_total',true);
            $ghimat_origin = wc_get_order_item_meta($r['order_item_id'],'_line_subtotal',true);
            $takhfif = $ghimat_origin - $ghimat;
            $order = wc_get_order( $r['order_id']);
            $coupons = '';
            if( $order->get_used_coupons() ){
                foreach( $order->get_used_coupons() as $coupon) {
                    $coupons .= ($coupons==''? '':'/' ). $coupon;
                }
            }
            $jam_ghimat+= $ghimat;
            $jam_ghimat_origin += $ghimat_origin;
            $jam_takhfif += $takhfif;
            $fname = get_post_meta($r['order_id'],'_billing_first_name',true);
            $lname = get_post_meta($r['order_id'],'_billing_last_name',true);
            $name = $fname.' '.$lname;
            $phone = get_post_meta($r['order_id'],'_billing_phone',true);
            if($phone==''){
                $user_id = get_post_meta($r['order_id'],'_customer_user',true);
                $us = get_user_by( 'id', $user_id );
                $phone = $us->user_login;
            }
            if($fname=='' && $lname==''){
                $user_id = get_post_meta($r['order_id'],'_customer_user',true);
                $name = get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
            }
            if($csv==0){
                $out .= 
                '<tr>
                    <td>
                    '.$name.'
                    </td>
                    <td>
                    '.$phone.'
                    </td>
                    <td>
                    '.get_post_meta($r['order_id'],'moaref_',true).'
                    </td>
                    <td>
                    '.$chairs.'
                    </td>
                    <td>
                        '.hamayesh_class::monize($ghimat_origin).'
                    </td>
                    <td>
                        '.hamayesh_class::monize($takhfif).' <br/> '.$coupons.'
                    </td>
                    <td>
                        '.hamayesh_class::monize($ghimat).'
                    </td>
                </tr>';
            }
            else{
                 
                $out.=trim(preg_replace('/\s\s+/', ' ', $name.',
                '.$phone.',
                '.get_post_meta($r['order_id'],'moaref_',true).',
                '.str_replace(',','-',$chairs).',
                '.$ghimat_origin.',
                '.$takhfif.',
                '.$ghimat.'
                '))."\n";
            }
            $p=null;
        }
        if($csv==0){
            $out.="<tr><td colspan='4' style='text-align:left' >جمع کل</td>
        <td>".hamayesh_class::monize($jam_ghimat_origin)."</td>
        <td>".hamayesh_class::monize($jam_takhfif)."</td>
        <td>".hamayesh_class::monize($jam_ghimat)."</td>
        </tr>";
        $out.='</table>';
        }
        else{
            $out.= trim(preg_replace('/\s\s+/', ' ', ",,,
            جمع کل
            ,
            ".$jam_ghimat_origin.",
            ".$jam_takhfif.",
            ".$jam_ghimat));
        }
        return $out;
    }
    public static function hamayesh_report_column($columns){
        $columns['report'] = 'گزارش'; // title
        return $columns;
    }
    // add video class report link
    public static function hamayesh_column_report_function( $column, $postid ) {
        if ( $column == 'report') {
            if(get_post_meta($postid, '_is_hamayesh', true) == 'yes'){
                echo "<a href='admin.php?page=hamayesh-product-rp&product_id=$postid' >مشاهده</a>";
            }else if(get_post_meta($postid, '_is_video', true) == 'yes'){
                echo "<a href='admin.php?page=video-product-rp&product_id=$postid' >مشاهده</a>";
            }else{
                echo "_";
            }
        }
        
    }
    public static function monize($str)
	{
		$out=$str;
		$out=str_replace(',','',$out);
		$out=str_replace('.','',$out);
		$j=-1;
		$tmp='';
		//$strr=explode(' ',$str);
		for($i=strlen($str)-1;$i>=0;$i--){
				//alert(txt[i]);
			if($j<2){
				$j++;
				$tmp=substr($str,$i,1) . $tmp;
			}else{
				$j=0;
				$tmp=substr($str,$i,1) . ',' . $tmp;
			}
		}                
		$out=$tmp;
	//	$out=($str);
	//	$out=strlen($str);
	//	$out=substr[strlen(
		return ($out);
	}
	public static function umonize($str){
		$str = perToEnNums($str);
		$out=$str;
		$out=str_replace(',','',$out);
		$out=str_replace('.','',$out);
		return($out);
    }
    public static function hs_add_custom_title() {
        global $product;
        $no_tarikh = (int)get_post_meta($product->id,'_no_tarikh',true);
        echo '<div class="hs-attr" >'.get_post_meta($product->id,'_teacher',true).'</div>';
        echo '<div class="hs-attr" >'.get_post_meta($product->id,'_city',true).'</div>';
        if($no_tarikh!=1){
            $tarikh = get_post_meta($product->id,'_tarikh',true);
            echo '<div class="hs-attr" >'.jdate("d F Y",strtotime($tarikh)).'</div>';
        }
    }
//------------------------------------- reserve old -------------------------------------
    public static function after_add_to_cart() {
        $id = (int) $_POST['product_id'];
        $reserve_times = (int) $_POST['reserve_time'];
        $_SESSION['reserve_time'][(int) $_POST['product_id']] = (int) $_POST['reserve_time'];
    }
    public static function wc_cart_item_name_hyperlink($title = null, $product_data, $cart_item = null, $cart_item_key = null) {
        global $wp_session;
        $reserve_time = $_SESSION['reserve_time'][$product_data['product_id']];
        $reserve = new reserve_class($reserve_time);
        if (isset($reserve->id)) {
            $tarikh = audit_class::perToEn(audit_class::hamed_pdate($reserve->tarikh));
            echo $title . '<br/>' . $tarikh . ' از ' . date("H:i", strtotime($reserve->start_time)) . ' الی ' . date("H:i", strtotime($reserve->end_time));
        } else {
            echo $title;
        }
    }
    public function reduseCapacity() {
        $my = new mysql_class;
        $my->ex_sqlx("update wp_hsreserve_data set zarfiat_used = zarfiat_used+1 where id= " . $this->id);
    }
    public function add_waranty_to_order_item_meta($item_id, $values, $cart_item_key) {
        // Retrieving the product id for the order $item_id
        $prod_id = wc_get_order_item_meta($item_id, '_product_id', true);
        // Getting the warranty value for this product Id
        $reserve = new reserve_class($_SESSION['reserve_time'][$prod_id]);
        $tarikh = audit_class::perToEn(audit_class::hamed_pdate($reserve->tarikh));
        $tarikh .= ' از ' . date("H:i", strtotime($reserve->start_time)) . ' الی ' . date("H:i", strtotime($reserve->end_time));
        wc_add_order_item_meta($item_id, 'زمان', $tarikh, true);
        $reserve->reduseCapacity();
        wc_add_order_item_meta($item_id, 'شماره رزرو', $_SESSION['reserve_time'][$prod_id], true);
    }
    public function update_reserve() {
        $reserve_id = (isset($_POST['reserve_id']) ? ($_POST['reserve_id']) : -1);
        $post_id = (isset($_POST['hs_post_id']) ? ($_POST['hs_post_id']) : -1);
        $val = (int) (isset($_POST['hs_val']) ? ($_POST['hs_val']) : -1);
        $my = new mysql_class;
        $my->ex_sqlx("update wp_hsreserve_data set zarfiat='$val' where id=$reserve_id");
        $rr = new reserve_class;
        $out = $rr->getReserve($post_id);
        die($out);
    }
}
?>
