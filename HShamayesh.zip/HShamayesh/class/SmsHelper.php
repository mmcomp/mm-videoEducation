<?php
require_once('Curl.php');
class SmsHelper
{
    const LINE = '9830001301477041';
    const USERNAME = 'sba14693';
    const PASSWORD = '5112876';
    const API_URL = 'http://94.232.173.124/services/wsSend.ashx';

    public static function send($numbers, $messages)
    {

        $params = array(
            'username=' . self::USERNAME,
            'password=' . urlencode(self::PASSWORD),
           'line=' . self::LINE,
            'mobile=' . $numbers,
            'message=' . urlencode($messages),
            'life_time=60',
        );
        $result = Curl::send('GET', 'http://94.232.173.124/services/wsSend.ashx', implode('&', $params));
        //var_dump($result);
        if (!($result['responseCode'] == 200 && $result['body']['status'] < 0)) {
            return false;

        } else {
            return true;
        }
    }
}


