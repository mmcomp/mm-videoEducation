function deletechair(hamayesh_data_id,pid) {
    var data = {
        "hamayesh_data_id": hamayesh_data_id,
        "hs_post_id": pid,
        "action": "hs_deletechair_hamayesh"
    };
    console.log(data);
    jQuery("#hs_hamayesh_tb").html('<img src="images/loading.gif" >');
    jQuery.post(ajaxurl, data, function (response) {
        jQuery("#hs_hamayesh_tb").html(response);
    }).fail(function () {
        jQuery("#hs_hamayesh_tb").html('خطا در ارتباط با سرور');
    }).always(function () {
        //
    });
    return false;
}
function hs_hamayesh_save_static_data(post_id,obj) {
    var data = {
        "_tarikh": jQuery("#_hamayesh_tarikh").val(),
        "_no_tarikh": jQuery("#_hamayesh_no_tarikh").val(),
        "_time": jQuery("#_hamayesh_time").val(),
        "_address": jQuery("#_hamayesh_address").val(),
        "_teacher": jQuery("#_hamayesh_teacher").val(),
        "_city": jQuery("#_hamayesh_city").val(),
        "_hamayesh_woo_post_id": post_id,
        "action": "hs_save_static_hamayesh"
    };
    jQuery("#hamayesh_static_span").append('<img class="khoon" src="images/loading.gif" >');
    jQuery(obj).hide();
    jQuery.post(ajaxurl, data, function (response) {
        res = JSON.parse(response);
        if(res.err=='1'){
            alert(res.msg);
            jQuery(".khoon").remove();
            return false;
        }
        else{
            alert(res.msg);
            jQuery(".khoon").remove();
        }
        
    }).fail(function () {
        alert('خطا در ارتباط با سرور');
    }).always(function () {
        jQuery(obj).show();
    });
    return false;
}
